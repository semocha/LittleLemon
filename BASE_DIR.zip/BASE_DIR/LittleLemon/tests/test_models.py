from django.test import TestCase
from restaurant.models import Menu

#TestCase class
class MenuTest(TestCase):
    def test_get_item(self):
        item = Menu.objects.create(MenuID=25, Title="IceCream", Price=80, Inventory=20)
                
        self.assertEqual(item, "IceCream : 80")