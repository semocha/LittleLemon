from django.db import models

# Create your models here.

class Booking(models.Model):
    BookingID = models.IntegerField(primary_key=True)
    Name = models.CharField(max_length=255)
    No_of_guests = models.IntegerField(null=False)
    BookingDate = models.DateField()
    
    def __str__(self) -> str:
        return self.Name

class Menu(models.Model):
    MenuID = models.IntegerField(primary_key=True)
    Title = models.CharField(max_length=255)
    Price = models.DecimalField(max_digits=10, decimal_places=2)
    Inventory = models.IntegerField(null=False)
    
    def __str__(self):
        return f'{self.Title} : {str(self.Price)}'